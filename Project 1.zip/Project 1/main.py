import tkinter as tk
from tkinter import messagebox, ttk
from backend import *

# Establish the connection to the SQLite databases
conn = connect_db()
student_conn = connect_student_db()
# Create table if it does not exist
initialize_db()
initialize_student_db()

def student_id_check(student_id, func):
    if not student_id: messagebox.showinfo("Alert", "Please Enter Student ID")
    elif student_exists(student_id): func(student_id)
    else: messagebox.showinfo("Alert", "Unrecognized Student ID")

def status_check(student_id):
    student = get_student(student_id)
    if student[2] == "Suspended": messagebox.showinfo("Alert", "Student ID is Suspended")
    else: insert_access_record(student_id)

def student_sign_in_out(student_id):
    student_id_check(student_id, status_check)

def admin_login(admin_id):
    if not admin_id: messagebox.showinfo("Alert", "Please Enter Admin ID")
    elif admin_id == 'admin': open_admin_panel()
    else: messagebox.showinfo("Alert","Unrecognized Admin ID")

# Function to open the Admin Panel in a new window
def open_admin_panel():
    admin_window = tk.Toplevel(root)  # Create a new window
    admin_window.title("Admin Panel")
    admin_window.geometry("600x600")

    # Entry to filter records
    # Student ID filter
    tk.Label(admin_window, text="Filter by Student ID:").pack(pady=1)
    filter_entry = tk.Entry(admin_window)
    filter_entry.pack(pady=1)
    # Date range filter
    tk.Label(admin_window, text="Filter by Date Range (YYYY-MM-DD HH:MM:SS):").pack(pady=1)
    # Start date
    tk.Label(admin_window, text="Start Date:").pack(pady=1)
    start_date_entry = tk.Entry(admin_window)
    start_date_entry.pack(pady=1)
    # End date
    tk.Label(admin_window, text="End Date:").pack(pady=1)
    end_date_entry = tk.Entry(admin_window)
    end_date_entry.pack(pady=1)

    # Button to apply the filter
    filter_button = tk.Button(admin_window, text="Filter/Refresh", command=lambda: update_records_display(filter_entry.get(), start_date_entry.get(), end_date_entry.get()))
    filter_button.pack(pady=1)

    #Treeview to display records in the Admin Panel
    records_tree = ttk.Treeview(admin_window, height=8)
    records_tree.pack(pady=1)
    records_tree['columns'] = ("Student ID", "Name", "Signed In", "Signed Out")
    #Formate columns
    records_tree.column("#0", width=1, minwidth=1)
    records_tree.column("Student ID", anchor=tk.W, width=120, minwidth=60)
    records_tree.column("Name", anchor=tk.W, width=120, minwidth=60)
    records_tree.column("Signed In", anchor=tk.W, width=120, minwidth=60)
    records_tree.column("Signed Out", anchor=tk.W, width=120, minwidth=60)
    #Headings
    records_tree.heading("Student ID", text="PSU ID")
    records_tree.heading("Name", text="Name")
    records_tree.heading("Signed In", text="Signed In")
    records_tree.heading("Signed Out", text="Signed Out")

    # Entry to filter records by student ID
    tk.Label(admin_window, text="Suspend/Unsuspend Students:").pack(pady=1)
    suspension_entry = tk.Entry(admin_window)
    suspension_entry.pack(pady=1)
    # Button to apply the filter
    suspension_button = tk.Button(admin_window, text="Suspend/Unsuspend", command=lambda: change_status(suspension_entry.get()) )
    suspension_button.pack(pady=1)
    #Treeview to display Students in the Admin Panel
    students_tree = ttk.Treeview(admin_window)
    students_tree.pack(pady=1)
    students_tree['columns'] = ("Student ID", "Name", "Status")
    #Formate columns
    students_tree.column("#0", width=1, minwidth=1)
    students_tree.column("Student ID", anchor=tk.W, width=120, minwidth=60)
    students_tree.column("Name", anchor=tk.W, width=120, minwidth=60)
    students_tree.column("Status", anchor=tk.W, width=120, minwidth=60)
    #Headings
    students_tree.heading("Student ID", text="PSU ID")
    students_tree.heading("Name", text="Name")
    students_tree.heading("Status", text="Status")

    # Function to update display in the admin window
    def update_records_display(student_id=None,  start_date=None, end_date=None):
        for row in records_tree.get_children():
            records_tree.delete(row)
        i = 0
        for record in fetch_records(student_id, start_date, end_date):
            records_tree.insert(parent='', index='end', iid=i, values=(record[0], record[1], record[2], record[3]))
            i += 1

    # Function to update display in the admin window
    def update_student_display():
        for row in students_tree.get_children():
            students_tree.delete(row)
        i = 0
        for student in get_students():
            students_tree.insert(parent='', index='end', iid=i, values=(student[0], student[1], student[2]))
            i += 1

    #Suspend/Unsuspend student
    def change_status(student_id):
        student_id_check(student_id, update_status)
        update_student_display()

    update_records_display()
    update_student_display()

# Main GUI Setup
root = tk.Tk()
root.title("SUN Lab Access System")
root.geometry("300x200")

# Labels and entry for student sign/out
tk.Label(root, text="Student ID:").pack(pady=5)
student_id_entry = tk.Entry(root)
student_id_entry.pack(pady=5)
# Button to sign in/out
student_button = tk.Button(root, text="SignIn/SignOut", command=lambda: student_sign_in_out(student_id_entry.get()))
student_button.pack(pady=5)

# Labels and entry for Admin Login
tk.Label(root, text="Admin ID:").pack(pady=5)
admin_entry = tk.Entry(root)
admin_entry.pack(pady=5)
# Button for Admin Login
admin_button = tk.Button(root, text="Login", command=lambda: admin_login(admin_entry.get()))
admin_button.pack(pady=5)

# Start the Tkinter main loop
root.mainloop()

# Close the connection when done
conn.close()

