import sqlite3
from datetime import datetime

# Establish the connection to the SQLite databases
def connect_db():
    return sqlite3.connect('sun_lab.db')

def connect_student_db():
    return sqlite3.connect('students.db')

# Create the database schema
def initialize_db():
    conn = connect_db()
    cursor = conn.cursor()

    # Create table if it does not exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS access_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            name TEXT NOT NULL,
            signed_in TEXT NOT NULL,
            signed_out TEXT
        )
    ''')

    conn.commit()
    conn.close()

def is_signed_in(cursor, student_id):
    cursor.execute("SELECT signed_in, signed_out FROM access_records WHERE student_id = ? ORDER BY signed_in DESC ", (student_id,))
    latest = cursor.fetchone()
    if latest is not None and latest[1] is None: return True
    else: return False

# Function to insert a record
def insert_access_record(student_id):
    conn = connect_db()
    cursor = conn.cursor()
    time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    name = get_student(student_id)[1]
    #if not signed in then Update sign_out
    if not is_signed_in(cursor, student_id):
        cursor.execute("INSERT INTO access_records (student_id, name, signed_in) VALUES (?, ?, ?)",
                       (student_id, name, time))
    else:
        cursor.execute("UPDATE access_records SET signed_out = ? WHERE student_id = ? AND signed_out IS NULL" ,
                       (time, student_id))

    conn.commit()
    conn.close()

# Function to fetch records based on student ID
def fetch_records(student_id=None, start_date=None, end_date=None):
    conn = connect_db()
    cursor = conn.cursor()
    query = "SELECT student_id, name, signed_in, signed_out FROM access_records WHERE 1=1"
    params = []
    if student_id:
        query += " AND student_id = ?"
        params.append(student_id)

    if start_date and end_date:
        query += " AND signed_in BETWEEN ? AND ?"
        params.extend([start_date, end_date])
    cursor.execute(query, params)
    records = cursor.fetchall()
    conn.close()
    return records


def get_student(student_id):
    conn = connect_student_db()
    cursor = conn.cursor()
    query = "SELECT student_id, name, status FROM students WHERE student_id = ?"
    cursor.execute(query, (student_id,))
    result = cursor.fetchone()
    conn.close()
    return result

def get_students():
    conn = connect_student_db()
    cursor = conn.cursor()
    query = "SELECT student_id, name, status FROM students WHERE 1=1"
    cursor.execute(query)
    result = cursor.fetchall()
    conn.close()
    return result


def insert_student(conn, student_id, name):
    cursor = conn.cursor()
    cursor.execute("INSERT OR IGNORE INTO students (student_id, name, status) VALUES (?, ?, ?)", (student_id, name, 'Active'))
    conn.commit()

def initialize_student_db():
    conn = connect_student_db()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS students (
            student_id TEXT PRIMARY KEY NOT NULL, 
            name TEXT,
            status TEXT
        )
    ''')
    # Insert hardcoded students
    insert_student(conn, '11111', 'John Doe')
    insert_student(conn, '22222', 'Jane Dee')
    insert_student(conn, '33333', 'Jack Smith')
    insert_student(conn, '44444', 'Jill Li')
    insert_student(conn, '55555', 'Joshua Finn')
    conn.commit()
    conn.close()

def student_exists(student_id):
    if get_student(student_id) is None: return False
    else: return True

def update_status(student_id):
    conn = connect_student_db()
    cursor = conn.cursor()
    status = get_student(student_id)[2]
    if status == "Active": status = "Suspended"
    else: status = "Active"
    cursor.execute("UPDATE students SET status = ? WHERE student_id = ?",
                   (status, student_id))
    conn.commit()
    conn.close()
